import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import struct
import re
from rclpy.qos import QoSProfile, ReliabilityPolicy

class ODriveFeedbackLogger(Node):
    def __init__(self):
        super().__init__('odrive_feedback_logger')
        qos = QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT)
        self.subscription = self.create_subscription(
            String,
            '/uart_rx_raw',
            self.listener_callback,
            qos
        )
        self.subscription  # prevent unused variable warning

    def listener_callback(self, msg):
        text = msg.data.strip()

        # Match CAN ID 0x429 (node 33, Get_Encoder_Estimates)
        match = re.match(r'.*CAN ID: 0x429\s+DLC: 8\s+Data:((?:\s[0-9A-F]{2}){8})', text)
        if match:
            hex_bytes = match.group(1).strip().split()
            try:
                byte_vals = bytes(int(b, 16) for b in hex_bytes)
                pos, vel = struct.unpack('<ff', byte_vals)
                self.get_logger().info(f"📍 Pos: {pos:.5f} turns | 🔄 Vel: {vel:.5f} turns/s")
            except Exception as e:
                self.get_logger().warn(f"Failed to decode frame: {e}")


def main(args=None):
    rclpy.init(args=args)
    node = ODriveFeedbackLogger()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
