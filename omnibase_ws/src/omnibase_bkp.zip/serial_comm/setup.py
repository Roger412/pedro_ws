from setuptools import find_packages, setup

package_name = 'serial_comm'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='roger',
    maintainer_email='joserogelioruiz12@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    entry_points={
        'console_scripts': [
            'serial_communication = serial_comm.serial_communication:main',
            'simple_rx = serial_comm.simple_rx:main',
            'odrive_dashboard = serial_comm.odrive_dashboard:main',
            'odrive_serial_communication = serial_comm.odrive_serial_communication:main',
        ],
    },
)
